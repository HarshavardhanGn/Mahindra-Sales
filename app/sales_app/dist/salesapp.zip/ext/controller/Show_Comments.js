sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{Comments_History:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=Show_Comments.js.map